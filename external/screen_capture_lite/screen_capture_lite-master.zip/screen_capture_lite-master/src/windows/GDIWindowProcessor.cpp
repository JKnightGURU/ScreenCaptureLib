#include "GDIWindowProcessor.h"

namespace SL {
    namespace Screen_Capture {





    }
}